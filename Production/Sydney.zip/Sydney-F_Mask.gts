G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-04-16T08:26:55+10:00*
G04 #@! TF.ProjectId,Sydney,5379646e-6579-42e6-9b69-6361645f7063,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-04-16 08:26:55*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.000000*%
%ADD11C,1.600000*%
%ADD12R,1.800000X1.800000*%
%ADD13C,1.800000*%
%ADD14RoundRect,4.000000X0.000010X-5.000000X0.000010X5.000000X-0.000010X5.000000X-0.000010X-5.000000X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,TP2*
X175894779Y-97500000D03*
G04 #@! TD*
G04 #@! TO.C,TP1*
X175894779Y-90000000D03*
G04 #@! TD*
G04 #@! TO.C,Switch*
X176000000Y-73000000D03*
X182500000Y-73000000D03*
X176000000Y-77500000D03*
X182500000Y-77500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,Resistor*
X237500000Y-72500000D03*
X229880000Y-72500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D1*
X234960000Y-95000000D03*
D13*
X237500000Y-95000000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,REF\u002A\u002A*
X160775000Y-74075000D03*
G04 #@! TD*
M02*
